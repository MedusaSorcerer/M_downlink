#!/usr/bin/env python
# _*_ coding: UTF-8 _*_
import sys

from flask import Flask, render_template

try:
    f = open('../config.py', 'r', encoding='UTF-8')
    conf = f.read()
    f.close()
    exec(conf)
except FileNotFoundError:
    print('没有找到配置文件 config.py')
    sys.exit()
except (Exception,):
    print('配置文件 config.py 解析错误')
    sys.exit()

app = Flask(__name__, template_folder=DOWNLOAD, static_folder=DOWNLOAD, static_url_path="")


@app.route('/')
def index():
    return render_template('links.html')


if __name__ == '__main__':
    app.run(debug=DEBUG, host=HOST, port=PORT)
